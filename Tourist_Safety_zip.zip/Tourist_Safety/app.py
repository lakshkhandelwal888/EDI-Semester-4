from flask import Flask, request, jsonify, render_template
import pymysql
import bcrypt
import hashlib
import datetime

app = Flask(__name__)
app.secret_key = 'tourist_safety_secret'

def get_db():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='Laksh@2601',
        database='tourist_safety'
    )

@app.route('/')
def home():
    return {"message": "Tourist Safety API is running!"}

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    full_name = data['full_name']
    email = data['email']
    password = data['password']
    phone = data['phone']
    emergency_contact_name = data['emergency_contact_name']
    emergency_contact_phone = data['emergency_contact_phone']
    password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    raw = f"{full_name}{email}{phone}{datetime.datetime.now()}"
    digital_id = hashlib.sha256(raw.encode()).hexdigest()
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("""
            INSERT INTO tourists (full_name, email, password_hash, phone, emergency_contact_name, emergency_contact_phone, digital_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (full_name, email, password_hash, phone, emergency_contact_name, emergency_contact_phone, digital_id))
        db.commit()
        return jsonify({"message": "You have registered successfully!", "digital_id": digital_id})
    except pymysql.err.IntegrityError:
        db.rollback()
        return jsonify({"message": "Email already registered!"}), 400
    except Exception as e:
        db.rollback()
        return jsonify({"message": str(e)}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data['email']
    password = data['password']
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("SELECT * FROM tourists WHERE email = %s", (email,))
        tourist = cursor.fetchone()
        if not tourist:
            return jsonify({"message": "Email not found!"}), 404
        stored_hash = tourist[3]
        if bcrypt.checkpw(password.encode('utf-8'), stored_hash.encode('utf-8')):
            return jsonify({
                "message": "Login successful!",
                "tourist_id": tourist[0],
                "full_name": tourist[1],
                "digital_id": tourist[7]
            })
        else:
            return jsonify({"message": "Incorrect password!"}), 401
    except Exception as e:
        return jsonify({"message": str(e)}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/updateLocation', methods=['POST'])
def update_location():
    data = request.json
    tourist_id = data['tourist_id']
    latitude = data['latitude']
    longitude = data['longitude']
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("""
            INSERT INTO locations (tourist_id, latitude, longitude)
            VALUES (%s, %s, %s)
        """, (tourist_id, latitude, longitude))
        db.commit()
        return jsonify({"message": "Location updated successfully!"})
    except Exception as e:
        db.rollback()
        return jsonify({"message": str(e)}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/getRisk', methods=['POST'])
def get_risk():
    data = request.json
    tourist_id = data['tourist_id']
    latitude = data['latitude']
    longitude = data['longitude']
    risk_score = 0
    current_hour = datetime.datetime.now().hour
    if 22 <= current_hour or current_hour < 6:
        risk_score += 20
    elif 20 <= current_hour < 22:
        risk_score += 10
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT latitude, longitude, radius FROM geofence_zones")
    zones = cursor.fetchall()
    cursor.close()
    db.close()
    for zone in zones:
        zone_lat, zone_lng, radius = zone
        distance = (((latitude - float(zone_lat)) ** 2) + ((longitude - float(zone_lng)) ** 2)) ** 0.5 * 111000
        if distance < radius:
            risk_score += 40
            break
        elif distance < radius * 2:
            risk_score += 15
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        SELECT latitude, longitude, recorded_at FROM locations
        WHERE tourist_id = %s ORDER BY recorded_at DESC LIMIT 5
    """, (tourist_id,))
    recent_locations = cursor.fetchall()
    cursor.close()
    db.close()
    if len(recent_locations) >= 5:
        lats = [float(r[0]) for r in recent_locations]
        lngs = [float(r[1]) for r in recent_locations]
        movement = ((max(lats) - min(lats)) ** 2 + (max(lngs) - min(lngs)) ** 2) ** 0.5
        if movement < 0.0001:
            risk_score += 20
        elif movement < 0.0005:
            risk_score += 10
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        UPDATE locations SET risk_score = %s
        WHERE tourist_id = %s ORDER BY recorded_at DESC LIMIT 1
    """, (risk_score, tourist_id))
    db.commit()
    cursor.close()
    db.close()
    if risk_score <= 30:
        risk_level = "SAFE"
    elif risk_score <= 55:
        risk_level = "LOW RISK"
    elif risk_score <= 75:
        risk_level = "MEDIUM RISK"
    else:
        risk_level = "HIGH RISK"
    return jsonify({
        "tourist_id": tourist_id,
        "risk_score": risk_score,
        "risk_level": risk_level
    })

@app.route('/alert', methods=['POST'])
def create_alert():
    data = request.json
    tourist_id = data['tourist_id']
    latitude = data['latitude']
    longitude = data['longitude']
    alert_type = data['alert_type']
    message = data.get('message', None)
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("""
            INSERT INTO alerts (tourist_id, latitude, longitude, alert_type, message)
            VALUES (%s, %s, %s, %s, %s)
        """, (tourist_id, latitude, longitude, alert_type, message))
        db.commit()
        return jsonify({"message": "Alert created successfully!"})
    except Exception as e:
        db.rollback()
        return jsonify({"message": str(e)}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/zones', methods=['GET'])
def get_zones():
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("SELECT id, zone_name, latitude, longitude, radius FROM geofence_zones")
        zones = cursor.fetchall()
        zones_list = []
        for zone in zones:
            zones_list.append({
                "id": zone[0],
                "zone_name": zone[1],
                "latitude": float(zone[2]),
                "longitude": float(zone[3]),
                "radius": zone[4]
            })
        return jsonify(zones_list)
    except Exception as e:
        return jsonify({"message": str(e)}), 500
    finally:
        cursor.close()
        db.close()

@app.route('/map')
def map_page():
    return render_template('map.html')

if __name__ == '__main__':
    app.run(debug=True)
    
