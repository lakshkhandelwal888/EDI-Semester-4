class Config:
    MYSQL_HOST     = 'localhost'
    MYSQL_USER     = 'root'
    MYSQL_PASSWORD = 'Laksh@2601'  
    MYSQL_DB       = 'tourist_safety'